# My First Project > 2025-02-25 4:12pm
https://universe.roboflow.com/traffic-hfq5b/my-first-project-a8cwc

Provided by a Roboflow user
License: CC BY 4.0

